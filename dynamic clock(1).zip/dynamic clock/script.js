
let time = document.querySelector('#time');
let dates = document.querySelector('#date');

setInterval(function(){
    let date = new Date();
   time.innerHTML = date.toLocaleTimeString();
   dates.innerHTML = date.toLocaleDateString();
},1000)


